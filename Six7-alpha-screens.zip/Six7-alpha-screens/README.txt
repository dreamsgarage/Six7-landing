Six7 alpha screens - 25 screenshots, 1440x1000, with the current Six7 logo.
Captured 29 October 2026 from the real apps at main (alpha 0.1.0).
service-desk (9), kanban (6), contracts-providers (5), crm (5)
Prepared by Gaston Fourcade, Entangled Forge Limited
